import boto3

def lambda_handler(event, context):
    rds = boto3.client('rds')
    response = rds.describe_db_instances()

    for db_instance in response['DBInstances']:
        db_instance_id = db_instance['DBInstanceIdentifier']
        rds.stop_db_instance(DBInstanceIdentifier=db_instance_id)
