import boto3

def lambda_handler(event, context):
    ec2 = boto3.client('ec2', region_name='Insert here the correct region')
    instances = ['Insert here the Id of the Instance']  
    ec2.stop_instances(InstanceIds=instances)